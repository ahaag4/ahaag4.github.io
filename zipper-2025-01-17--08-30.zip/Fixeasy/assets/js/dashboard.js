document.getElementById('logout').addEventListener('click', async () => {
      try {
          await auth.signOut();
              alert('Logged Out Successfully!');
                  window.location.href = "signin.html";
                    } catch (error) {
                        alert(error.message);
                          }
                          });
                          
})