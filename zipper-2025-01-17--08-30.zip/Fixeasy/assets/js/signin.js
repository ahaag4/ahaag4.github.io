document.getElementById('signin-form').addEventListener('submit', async (e) => {
      e.preventDefault();

        const email = document.getElementById('email').value;
          const password = document.getElementById('password').value;

            try {
                // Sign in user
                    await auth.signInWithEmailAndPassword(email, password);
                        alert('Sign In Successful!');
                            window.location.href = "dashboard.html"; // Redirect to dashboard
                              } catch (error) {
                                  alert(error.message);
                                    }
                                    });
                                    
})