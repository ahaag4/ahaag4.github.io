// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC0dYCbPoH5mH1QeLI31xrfqnUSbT8Bao0",
    authDomain: "fixeasy-568cd.firebaseapp.com",
      projectId: "fixeasy-568cd",
        storageBucket: "fixeasy-568cd.firebasestorage.app",
          messagingSenderId: "839456909521",
            appId: "1:839456909521:web:8555cb99e40cb5e1753df0",
              measurementId: "G-RQD3RPMZKS"
               };

              // Initialize Firebase
              firebase.initializeApp(firebaseConfig);
              firebase.analytics();
              const auth = firebase.auth();
              const db = firebase.firestore();
