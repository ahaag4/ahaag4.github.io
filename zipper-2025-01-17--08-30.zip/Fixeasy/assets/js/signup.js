document.getElementById('signup-form').addEventListener('submit', async (e) => {
      e.preventDefault();

        const name = document.getElementById('name').value;
          const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

              try {
                  // Create user with email and password
                      const userCredential = await auth.createUserWithEmailAndPassword(email, password);

                          // Save additional user data to Firestore
                              await db.collection('users').doc(userCredential.user.uid).set({
                                    name: name,
                                          email: email,
                                                createdAt: new Date(),
                                                      role: "user",
                                                          });

                                                              alert('Sign Up Successful!');
                                                                  window.location.href = "dashboard.html"; // Redirect to dashboard
                                                                    } catch (error) {
                                                                        alert(error.message);
                                                                          }
                                                                          });
                                                                          
})